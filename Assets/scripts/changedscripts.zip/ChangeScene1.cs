﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class ChangeScene1 : MonoBehaviour {

    

    public void Quit()
    {
        // zorgt ervoor dat de game gesloten kan worden door de quit knop.
        Application.Quit();
    }
}
